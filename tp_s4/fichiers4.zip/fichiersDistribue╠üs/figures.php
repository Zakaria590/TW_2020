<?php
 require('lib/fonctionsSVG.php');
 $centreX= 70;
 $centreY= 90;
 $rayon = 50;
 /* inclusion de la page */
 require('views/pageFigures.php');
?>