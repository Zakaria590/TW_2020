<?php

const DB_USER = "ouaichouche";
const DB_PASSWORD = "";
const DB_DSN = "pgsql:host=localhost;dbname=".DB_USER;
?>
