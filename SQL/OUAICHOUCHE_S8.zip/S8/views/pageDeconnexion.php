
<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
    <meta charset="UTF-8"/>
    <title>Deconnexion</title>
    <link rel="stylesheet" type="text/css" href="style_authent.css" />
  </head>
<body>
  <h2> Vous avez été déconnecté </h2>
  <a href='index.php'>Revenir à la page de login</a>
</body>
</html>
