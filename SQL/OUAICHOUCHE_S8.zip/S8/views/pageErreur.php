
<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
    <meta charset="UTF-8"/>
    <title>Création d'utilisateur</title>
</head>
<body>
<h2>Erreur</h2>
<p>Bug !</p>
</body>
</html>
