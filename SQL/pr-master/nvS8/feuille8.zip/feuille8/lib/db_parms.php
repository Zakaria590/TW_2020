<!-- Salah Zakaria OUAICHOUCHE -->

<?php
define("DB_USER", "ouaichouche");
define("DB_PASSWORD", "z08011995");
define("DB_DSN", "pgsql:host=localhost;dbname=".DB_USER);
?>
