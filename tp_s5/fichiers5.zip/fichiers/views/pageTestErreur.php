<?php
// script de test, uniquement pour la partie 1, invoqué par le script principal
$errorPage=TRUE;
require('views/pageTest.php');
?>