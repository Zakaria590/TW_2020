<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr" xml:lang="fr">

<head>

  <meta charset="UTF-8" />
  <title>Test PHP</title>

</head>

<body>

<h2>Premier test PHP</h2>

<p>
<?php 
$n=7; $d=3; 
echo "$n/$d egale : " . ($n/$d) ."<br />"; 
?>
</p>

</body>

</html>
