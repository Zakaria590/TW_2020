<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Premier exercice PHP</title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="iniPHP.css" />
    </head>
    <body>
        <header>
            <h1>Premier exercice PHP</h1>
            <h2>Réalisé par <span class="nom">André Daizardizde</span></h2>
        </header>
        <section>
            <h2>Question 1</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam in gravida ante. Donec id orci sit amet dui tincidunt imperdiet ac in augue. Duis tempor elit a rhoncus luctus. Aliquam quis laoreet ex. Ut pulvinar egestas enim, et sagittis nibh dictum et. Aliquam vehicula lectus et ipsum facilisis, sed dictum risus venenatis. Mauris dictum sit amet ipsum id aliquam. Donec neque elit, iaculis ut egestas eu, aliquet eu leo.
        </section>
        <section>
            <h2>Question 2</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam in gravida ante. Donec id orci sit amet dui tincidunt imperdiet ac in augue. Duis tempor elit a rhoncus luctus. Aliquam quis laoreet ex. Ut pulvinar egestas enim, et sagittis nibh dictum et. Aliquam vehicula lectus et ipsum facilisis, sed dictum risus venenatis. Mauris dictum sit amet ipsum id aliquam. Donec neque elit, iaculis ut egestas eu, aliquet eu leo. 
        </section>
    </body>
    
</html>