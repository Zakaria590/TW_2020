Dépôt des TP de POO de Salah Zakaria OUAICHOUCHE.

Le but de cet exercice est :
 - apprendre a ecrire une classe.
 - apprendre a reediger une documentation.
 - utiliser une methodologie rigoureuse basee sur les tests unitaires.