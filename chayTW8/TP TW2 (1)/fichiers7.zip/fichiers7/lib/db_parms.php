<?php
const DB_USER = "zouhri";  // à modifier
const DB_PASSWORD = ""; // à modifier
const DB_DSN = "pgsql:host=localhost;dbname=".DB_USER;
?>
