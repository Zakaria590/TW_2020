<?php
define("DB_USER", "zouhri");
define("DB_PASSWORD", "22/10/2016");
define("DB_DSN", "pgsql:host=localhost;dbname=".DB_USER);
?>
