<?php
require('views/pageRegister.php');
?>
